import pandas as pd
import re
from tqdm import tqdm


def update_given_way(df):
    column = "M_GIVEN_WAY_DESC"
    given_ways = ['OPHTALM', 'RESPIR', 'IV', 'SC', 'ORAL', 'IM']

    ORAL_to_replace = ['ORAL CHEWABLE', 'PO', 'ORAL TRANSMUCOSAL', 'ORAL SUCKNESS', 'P.O.', 'P.O', 'P.0']
    SC_to_replace = ['S.C', 'S.C.', 'S/C', 'S.C-DEEP']
    IV_to_replace = ['I.V', 'I.V DRIP', 'IV DRIP', 'IV-DRIP', 'I.V CONTIN', 'I.V.', 'I.V. DRIP', 'IV BOLUS', 'I.V-SLOW',
                     'I.V BOLUS']
    IM_to_replace = ['I.M', 'I.M.']

    df[column] = df[column].replace(ORAL_to_replace, 'ORAL')
    df[column] = df[column].replace(SC_to_replace, 'SC')
    df[column] = df[column].replace(IV_to_replace, 'IV')
    df[column] = df[column].replace(IM_to_replace, 'IM')

    df = df[df[column].isin(given_ways)]
    return df


def drop_meds(df, n):
    value_counts = df.groupby(['CODE_ATC', 'M_GIVEN_WAY_DESC']).size().reset_index(name='counts')
    value_counts = value_counts.sort_values('counts')

    for index, row in value_counts.iterrows():
        if row['counts'] > n:
            break
        med = row['CODE_ATC']
        given_way = row['M_GIVEN_WAY_DESC']
        rows_to_drop = df[(df['CODE_ATC'] == med) & (df['M_GIVEN_WAY_DESC'] == given_way)].index
        df.drop(rows_to_drop, inplace=True)
        return df


def extract_numeric(value):
    if type(value) is str:
        match = re.search(r'(\d+\.\d+|\d+)', value)
        return float(match.group(0)) if match else None
    return float(value)


def extract_unit(value):
    if type(value) is str:
        match = re.search(r'[a-zA-Z]+', value)
        return match.group(0) if match else None
    return None


def convert_dose(row, target_unit):
    conversion_rates = {
        ('G', 'MG'): 1000,
        ('MG', 'G'): 0.001,
        ('TSP', 'ML'): 5,
        ('ML', 'TSP'): 0.2,
        ('GR', 'MG'): 64.8,
        ('MG', 'GR'): 0.015,
        ('DR', 'G'): 3.5,
        ('G', 'DR'): 0.28,
        ('MG', 'MCG'): 1000,
        ('MCG', 'MG'): 0.001,
        ('ML', 'NANO'): 1000000,
        ('NANO', 'ML'): 0.000001}

    med = row['CODE_ATC']
    unit = row['UNIT_OF_MEASURE']
    dose = row['M_DOSAGE']

    if type(dose) is not float:
        return None

    if unit != target_unit:
        conversion_key = (unit, target_unit)
        if conversion_key in conversion_rates:
            conversion_rate = conversion_rates[conversion_key]
            dose_result = dose * conversion_rate
            return dose_result
        else:
            return None
    return dose


if __name__ == "__main__":
    file_path = 'home_hospital_meds_vertical.csv'
    df = pd.read_csv(file_path)  # will raise a warning, just keep going :)

    ''' process part '''
    # remove columns with null M_DOSAGE
    df.dropna(subset=['M_DOSAGE'], inplace=True)

    # update given way column, remain only specific values
    df = update_given_way(df)

    # extract the unit from M_DOSAGE to UNIT_OF_MEASURE
    df['UNIT_OF_MEASURE'] = df.apply(
        lambda row: extract_unit(row['M_DOSAGE']) if pd.isna(row['UNIT_OF_MEASURE']) else row['UNIT_OF_MEASURE'],
        axis=1)
    df['UNIT_OF_MEASURE'] = df['UNIT_OF_MEASURE'].str.upper()

    # remove columns with null UNIT_OF_MEASURE
    df.dropna(subset=['UNIT_OF_MEASURE'], inplace=True)

    # convert the M_DOSAGE to only numeric or None
    df['M_DOSAGE'] = df['M_DOSAGE'].apply(extract_numeric)

    ''' convert units part '''
    # get all the meds
    meds = df['CODE_ATC'].unique()

    # update meds unit
    for med in tqdm(meds):
        # med_errors = []
        df_for_med = df[df['CODE_ATC'] == med]
        given_ways = df_for_med['M_GIVEN_WAY_DESC'].unique()
        for way in given_ways:
            df_med_way = df_for_med[df_for_med['M_GIVEN_WAY_DESC'] == way]
            unique_units = set(df_med_way[
                                   'UNIT_OF_MEASURE'].value_counts().dropna().index)  # get how many different units for the specific med
            if len(unique_units) == 1:  # all samples in the same unit
                continue
            common_unit = df_med_way['UNIT_OF_MEASURE'].value_counts().index[0]  # extract the most common unit
            for index, row in tqdm(df_med_way.iterrows()):
                dose = convert_dose(row, common_unit)
                # update the main df
                df.at[index, 'M_DOSAGE'] = dose
                df.at[index, 'UNIT_OF_MEASURE'] = common_unit

    # drop meds
    df = drop_meds(df, 500)

    df.dropna(subset=['M_DOSAGE'], inplace=True)
    df.to_csv("processed_data.csv", index=False)